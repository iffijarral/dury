<?php 

require_once 'start.php';

require_once FRONTEND_INCLUDE . 'header.php';

if(!empty($_GET)) {
    $action = $_GET['action'];
    
    if($action == 'edit' || $action == 'create') {

        require_once FRONTEND_PAGE . 'operations.php';

    } else {

        require_once FRONTEND_PAGE . 'home.php';
        
    }
    
} else {
    require_once FRONTEND_PAGE . 'home.php';
}    


require_once FRONTEND_INCLUDE . 'footer.php';
