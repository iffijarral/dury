-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Vært: localhost
-- Genereringstid: 04. 01 2021 kl. 22:46:14
-- Serverversion: 10.4.11-MariaDB
-- PHP-version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dury`
--

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `languages`
--

CREATE TABLE `languages` (
  `languages_id` int(11) NOT NULL,
  `languages_name` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `languages`
--

INSERT INTO `languages` (`languages_id`, `languages_name`) VALUES
(1, 'Danish'),
(2, 'English'),
(3, 'Norwegian');

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `products`
--

CREATE TABLE `products` (
  `products_id` int(11) NOT NULL,
  `products_reference` varchar(255) NOT NULL,
  `products_price` float NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `products`
--

INSERT INTO `products` (`products_id`, `products_reference`, `products_price`) VALUES
(1, 'KI-0500', 189),
(2, '600500', 50);

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `products_description`
--

CREATE TABLE `products_description` (
  `products_description_id` int(11) NOT NULL,
  `products_id` int(11) NOT NULL,
  `languages_id` int(11) NOT NULL,
  `products_description_name` varchar(255) NOT NULL,
  `products_description_short_description` text NOT NULL,
  `products_description_description` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `products_description`
--

INSERT INTO `products_description` (`products_description_id`, `products_id`, `languages_id`, `products_description_name`, `products_description_short_description`, `products_description_description`) VALUES
(1, 1, 1, 'Hæklenålesæt', 'Godt hæklenålesæt', 'Meget mere info om hæklenålene'),
(2, 1, 2, 'Crochet hook set', 'Some text', 'More text'),
(3, 1, 3, 'Heklenåleset', 'Veldig bra heklenåleset', 'Mer på settet'),
(4, 2, 1, 'Diverse produkt', 'Lidt tekst', 'Mere tekst\r\n<p>Hej <u>med</u> dig</p>'),
(5, 2, 2, 'Miscellaneous', 'Text miscellaneous', 'Text miscellaneous more more more'),
(6, 2, 3, 'Norsk diverse', 'Tekst nummer 1', 'Mer tekst på norsk');

--
-- Begrænsninger for dumpede tabeller
--

--
-- Indeks for tabel `languages`
--
ALTER TABLE `languages`
  ADD PRIMARY KEY (`languages_id`);

--
-- Indeks for tabel `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`products_id`);

--
-- Indeks for tabel `products_description`
--
ALTER TABLE `products_description`
  ADD PRIMARY KEY (`products_description_id`),
  ADD KEY `products_id` (`products_id`,`languages_id`);

--
-- Brug ikke AUTO_INCREMENT for slettede tabeller
--

--
-- Tilføj AUTO_INCREMENT i tabel `languages`
--
ALTER TABLE `languages`
  MODIFY `languages_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Tilføj AUTO_INCREMENT i tabel `products`
--
ALTER TABLE `products`
  MODIFY `products_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Tilføj AUTO_INCREMENT i tabel `products_description`
--
ALTER TABLE `products_description`
  MODIFY `products_description_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
