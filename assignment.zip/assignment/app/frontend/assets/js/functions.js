$(document).ready(function () {
    
    $(document).off('click').on('click', '.deleteItem', function (e) {
        
        e.preventDefault();        
        
        if (!confirm('Produktet slettes permanent')) {
            return false;
        }         

        var productId = $(this).attr("data-id");

        var data = {
            productID: productId,
            action: 'delete'
        }

        $.ajax({           
            type: 'POST',

            url: 'app/backend/controller/Controller.php',

            data: data,

            success: (response) => {
                
                var responseData = JSON.parse(response);
                
                if(responseData.status) {
                    alert(responseData.message)
                    window.location.href = 'index.php';
                }                    
                else {
                    alert(responseData.message)
                    
                }                    
                
            },

            error: () => {
                alert('error occored');
            }
        });

    });

});