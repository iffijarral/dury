<?php   
    $error = '';

   try {
    $productOperations = new ProductOperations();

    $products = $productOperations->getProducts();
    
   } catch (\Throwable $th) {
       $error = $th->getMessage();
   }
                    
   if(empty($error)) {

   
?>
  <div id="productsShowCase" >
    <a href="index.php?action=create">Ny Produkt</a>
    <table>
        <tr> 
            <th>Produkt</th>            
            <th>Redigere</th>
            <th>Slet</th>
        </tr>
    <?php 
        foreach($products as $product) {        
    ?>        
        <tr>
            <td> <?php echo $product->getProdName(); ?> </td>            
            <td><a class="editItem" href="index.php?action=edit&id=<?php echo $product->getProdID(); ?>"><i class="far fa-edit"></i></a></td>
            <td><a class="deleteItem" data-id="<?php echo $product->getProdID(); ?>" href="#"><i class="far fa-trash-alt"></i></a></td>
        </tr>        
    <?php 
        }
    ?>
    </table>
  </div>
<?php 

   } else {
        echo '<h2>'.$error.'</h2>';
   }
?>