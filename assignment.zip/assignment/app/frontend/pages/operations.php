<?php   
    
    $error = '';

    try {
        if(!empty($_GET)) 
        {
            $productOperations = new ProductOperations();
    
            if($_GET['action'] == 'edit')
            {
                $productID = $_GET['id'];                        
            
                $productInfo = $productOperations->getProductInfo($productID);
                
                $product = $productInfo['product'];
            
                $productDescList = $productInfo['descriptionList'];
            }  else {
                $languagesList = $productOperations->getLanguages();
            }      
        } else {
            header("Location: /index.php");
            exit(0);
        }        
    } catch (\Throwable $th) {
        $error = $th->getMessage();
    }    
    
    if(empty($error)) {    
?>

<div class="outerDiv">

    <div class="constant">
        <table>
            <tr>
                <td>
                    Varenummer
                </td>
                <td>
                    <input type="text" name="name" value="<?php echo $_GET['action'] == 'edit' ? $product->getReference() : ''; ?>" id="name">
                </td>
            </tr>
            <tr>
                <td>
                    Pris
                </td>
                <td>
                    <input type="text" name="price" value="<?php echo $_GET['action'] == 'edit' ? $product->getPrice() : ''; ?>">
                </td>
            </tr>
        </table>
    </div>
    <div class="variable">
        <?php               
            $length = $_GET['action'] == 'edit' ? sizeof($productDescList) : sizeof($languagesList);

            for($a = 0; $a < $length; $a++)
            {
        
            
            

        ?>
            <div>

                <label style="padding-left: 1em;"><?php echo $_GET['action'] == 'edit' ? $productDescList[$a]->getLangName(): $languagesList[$a]->getName(); ?></label>

                <div style="border: 1px solid; padding: 1em;">
                    <div class="myRow">
                        <div>
                            <label>Varenavn</label>
                        </div>

                        <div style="width: 100%;">
                            <input type="text" name="name" value="<?php echo $_GET['action'] == 'edit' ? $productDescList[$a]->getProdName() : ''; ?>" id="name" style="width: 100%;">
                        </div>
                    </div>
                    <p><label>Korttekst</label>
                        <textarea id="comment" name="comment" rows="8"><?php echo $_GET['action'] == 'edit' ? $productDescList[$a]->getShortDescription() : ''; ?></textarea>
                    </p>
                    <p><label>Langetekst</label>
                        <textarea id="comment" name="comment" rows="8"><?php echo $_GET['action'] == 'edit' ? $productDescList[$a]->getLongDescription() : ''; ?></textarea>
                    </p>
                </div>

            </div>
        <?php
        }
        ?>
    </div>
</div>

<?php 

    } else {
        echo '<h2>'.$error.'</h2>';
    }
?>