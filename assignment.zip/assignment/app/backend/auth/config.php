<?php

$GLOBALS['config'] = array(

    'app' => array(
        'name'          => 'Assignment',
    ),

    'mysql' => array(
        'host'          => 'localhost',
        'username'      => 'root',
        'password'      => '',
        'db_name'        => 'dury'
    ),
    
);
