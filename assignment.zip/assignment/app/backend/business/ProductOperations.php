<?php

class ProductOperations{
    private $_db;

    public function __construct()
    {
        $this->_db = Database::getInstance();
    }

    public function getLanguages()
    {
        $sql = "SELECT * from languages";

        $results = $this->_db->Select($sql);

        $languageList = array();

        foreach($results as $result)
        {
            
            array_push(
                $languageList, 
                new Language(                    
                    $result['languages_id'], 
                    $result['languages_name']                    
                )
            );
        }

        return $languageList;
    }

    public function getProductInfo($productID) 
    {
        $sql = "SELECT p.products_id AS productID, p.products_reference AS reference, 
        p.products_price AS price, pd.products_description_name AS productName,
        pd.products_description_short_description AS shortDescription, pd.products_description_description
        AS longDescription, lang.languages_name AS langName
        FROM products AS p
        INNER JOIN products_description AS pd
        ON p.products_id = pd.products_id
        INNER JOIN languages AS lang
        ON pd.languages_id = lang.languages_id
        WHERE p.products_id = :id";


        $params = array(
            'id' => $productID
        );
      
        $results = $this->_db->Select($sql, $params);              
        
        if(empty($results)) {
            throw new Exception('Invalid product ID');
        }

        $product = new Product((int)$results[0]['productID'], $results[0]['reference'], (float)$results[0]['price']);

        $descriptionList = array();

        foreach($results as $result) 
        {
            array_push(
                $descriptionList,
                new Description(
                    (int)$result['productID'],                                        
                    $result['productName'],
                    $result['langName'],
                    $result['shortDescription'],
                    $result['longDescription']
                )   
            );
        }

        $resultSet = array(
            'product' => $product,

            'descriptionList' => $descriptionList
        );
        
        return $resultSet;
    }

    public function getProducts($langID = null)
    {
        $sql = "SELECT p.products_id AS productID, p.products_reference AS reference, 
                p.products_price AS price, pd.products_description_name AS productName,
                pd.products_description_short_description AS shortDescription, pd.products_description_description
                AS longDescription, lang.languages_name AS langName
        FROM products AS p
        INNER JOIN products_description AS pd
        ON p.products_id = pd.products_id
        INNER JOIN languages AS lang
        ON pd.languages_id = lang.languages_id
        WHERE lang.languages_id = :id";

        $langID = $langID ??  1;

        $params = array(
            'id' => $langID
        );
         

        $results = $this->_db->Select($sql, $params);
        
        if(empty($results)) {
            throw new Exception('Ingen tilgængelig data');
        }

        $productList = array();

        foreach($results as $result)
        {
            
            array_push(
                $productList, 
                new Description(                                        
                    (int)$result['productID'],
                    $result['productName']                                                            
                )
            );
        }

        return $productList;
    }

    public function deleteProduct($productID)
    {
        
        try {
            if($this->_db->Remove("Delete from products where products_id = :id",['id' => $productID])) {

                if($this->_db->Remove("Delete from products_description where products_id = :id",['id' => $productID])) {
                    return true; 
                } else {
                    return false;
                }
                
            } else {
                return false;
            }
                        
        } catch(Throwable $e) {
            throw new Exception($e->getMessage());   
        }	
        
    }
}
