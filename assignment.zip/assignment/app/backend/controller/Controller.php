<?php

require_once $_SERVER['DOCUMENT_ROOT'] . '/assignment/start.php';

if (isset($_POST)) {

    $action = '';

    if (!empty($_POST["action"])) {
        $action = $_POST["action"];

        switch ($action) {
            case 'edit':
                # code...
                break;
            case 'delete':
                deleteProduct($_POST['productID']);
                break;
            default:
                # code...
                break;
        }
    }
} else {
    redirect('index.php');
}

function deleteProduct($productID)
{
    
    $productOperations = new ProductOperations();
    $response = array();

    try {
        if ($productOperations->deleteProduct($productID)) {
            $response['status'] = true;
            $response['message'] = 'Produktet er blevet slettet';
        } else {
            $response['status'] = false;
            $response['message'] = 'Produktet kunne ikke slettes';
        }
    } catch (Throwable $e) {
        $response['status'] = false;
        $response['message'] = $e->getMessage();
    }

    echo json_encode($response);
}

function redirect($url)
{
    ob_start();
    header('Location: ' . $url);
    ob_end_flush();
    die();
}
