<?php

require APP_ROOT.'app/backend/core/Database.php';
require APP_ROOT.'app/backend/auth/config.php';
require APP_ROOT.'app/backend/core/Helpers.php';

require APP_ROOT.'app/backend/models/Product.php';
require APP_ROOT.'app/backend/models/Language.php';
require APP_ROOT.'app/backend/models/Description.php';

require APP_ROOT.'app/backend/business/ProductOperations.php';
